
package MisClases;

public class Oficios {
    
    private String of;
    private int trab;

    public Oficios() {
        
    }

    public Oficios(String of, int trab) {
        this.of = of;
        this.trab = trab;
    }

    public String getOf() {
        return of;
    }

    public int getTrab() {
        return trab;
    }

    public void setOf(String of) {
        this.of = of;
    }

    public void setTrab(int trab) {
        this.trab = trab;
    }
    
    
    
}
